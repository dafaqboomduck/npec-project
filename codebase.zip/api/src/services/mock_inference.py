"""Mock inference service for development and frontend integration."""

from __future__ import annotations

import logging
import time
import uuid
from datetime import datetime, timezone

from api.src.schemas.predictions import (
    Plant,
    PredictionMetadata,
    PredictionResponse,
    PredictionStatus,
)
from api.src.services.base import AbstractInferenceService

logger = logging.getLogger(__name__)

# Version string returned while the mock is active
_MOCK_MODEL_VERSION = "mock-v0.0.0"


class MockInferenceService(AbstractInferenceService):
    """Fake inference that satisfies the API contract without a real model.

    The returned plants are hard-coded to match the
    example response in `api_spec.yaml`, making it easy to verify that the
    frontend renders results correctly.
    """

    async def run(
        self,
        image_bytes: bytes,
        filename: str,
    ) -> tuple[PredictionResponse, None]:
        """Return a mock prediction with two plants.

        Args:
            image_bytes: Ignored by this implementation.
            filename: Ignored by this implementation.

        Returns:
            A mock `PredictionResponse`.
        """
        start = time.perf_counter()

        mock_plants = [
            Plant(
                plant_id=1,
                tip_x=412,
                tip_y=1803,
                root_length_px=1643.2,
                root_length_mm=88.7,
            ),
            Plant(
                plant_id=2,
                tip_x=967,
                tip_y=1765,
                root_length_px=1501.4,
                root_length_mm=81.1,
            ),
        ]

        processing_ms = int((time.perf_counter() - start) * 1000)

        prediction = PredictionResponse(
            prediction_id=uuid.uuid4(),
            status=PredictionStatus.OK,
            metadata=PredictionMetadata(
                model_version=_MOCK_MODEL_VERSION,
                inference_timestamp=datetime.now(timezone.utc),
                processing_time_ms=processing_ms,
                input_resolution=[2775, 2048],
                input_channels=1,
                normalisation_applied=True,
                scale_factor_mm_per_px=0.05405,
            ),
            segmentation_mask_url=None,  # No mask generated in mock mode
            plants=mock_plants,
            warnings=["MOCK_INFERENCE"] if not mock_plants else [],
        )

        logger.info(
            "MockInferenceService: returning %d plant(s) for '%s'",
            len(mock_plants),
            filename,
        )

        return prediction, None

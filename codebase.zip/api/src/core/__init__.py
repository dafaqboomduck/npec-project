"""Security utilities."""

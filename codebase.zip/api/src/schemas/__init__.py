"""Pydantic request and response schemas for the API."""
